#ifndef PRINT_USAGE_H
#define PRINT_USAGE_H

void printUsage(char* PROG_NAME);

#endif // PRINT_USAGE_H
